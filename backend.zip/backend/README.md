# SmartLinks Backend

Instructions pour lancer le backend :

```bash
npm install
cp .env.example .env
npm start
```